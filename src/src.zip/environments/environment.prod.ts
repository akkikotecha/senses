export const environment = {
  production: true,
  base_url: window.location.origin + '/api/',
  baseurlhostname:
    window.location.protocol + '//' + window.location.hostname + '/',
};
