export class ChangePassword
{
    id:"";
    oldPassword:any="";
    password:any="";

}