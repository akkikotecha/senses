export class Login
{
    email:any="";
    password:any="";

}