import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-product-detail-page',
  templateUrl: './admin-product-detail-page.component.html',
  styleUrls: ['./admin-product-detail-page.component.css']
})
export class AdminProductDetailPageComponent {

}
