import { Component } from '@angular/core';

@Component({
  selector: 'app-loader-products',
  templateUrl: './loader-products.component.html',
  styleUrls: ['./loader-products.component.css']
})
export class LoaderProductsComponent {

}
