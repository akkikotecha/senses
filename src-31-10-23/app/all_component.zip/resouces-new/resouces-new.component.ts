import { Component } from '@angular/core';

@Component({
  selector: 'app-resouces-new',
  templateUrl: './resouces-new.component.html',
  styleUrls: ['./resouces-new.component.css']
})
export class ResoucesNewComponent {

}
